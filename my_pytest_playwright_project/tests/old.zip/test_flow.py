# tests/test_flow.py
import sys
import os
from pathlib import Path
import subprocess
import json
import numpy as np
import pytest

# --- Ensure the /app root (one level up) is importable ---
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))  # add /app to sys.path before importing src

# --- Now safe to import local modules ---
from src.step_executor import StepExecutor, Step
from src.base_actions import BaseActions


def generate_test_matrix(n=5):
    """Example: generate n combinations of numeric credentials."""
    a = np.arange(1, n + 1)
    b = np.arange(100, 100 + n)
    combos = np.stack(np.meshgrid(a, b), -1).reshape(-1, 2)
    return combos[:n]


@pytest.mark.parametrize("combo", generate_test_matrix(4))
def test_execute_flow(page, config, session_logger, combo):
    """Demo test that executes simple UI-like steps using StepExecutor."""

    session_logger.info("Starting test_execute_flow with combo %s", combo.tolist())

    # Placeholder: Excel→XML transform (can be skipped)
    transform_script = ROOT / "tools" / "excel_to_xml_transform.py"
    excel_input = config.get("excel_path")
    if excel_input and transform_script.exists():
        session_logger.info("Running Excel→XML transform")
        subprocess.run(
            ["python", str(transform_script), "--input", excel_input],
            check=True,
        )
    else:
        session_logger.info("Skipping Excel→XML transform (placeholder not found)")

    # Step execution example
    actions = BaseActions(page, session_logger) if page else None
    executor = StepExecutor(actions) if actions else None

    steps = [
        Step(keyword="click", target="text=Sign in"),
        Step(keyword="enter", target="input[name='username']", value=str(int(combo[0]))),
        Step(keyword="enter", target="input[name='password']", value=str(int(combo[1]))),
        Step(keyword="click", target="button[type='submit']"),
        Step(
            keyword="screenshot",
            target=str(ROOT / "artifacts" / f"step_{combo[0]}_{combo[1]}.png"),
        ),
    ]

    if executor:
        results = executor.run_steps(steps)
        session_logger.info("Executor results: %s", results)

        # Simple assertion: verify UI state (mock)
        try:
            assert "Welcome" in page.content()
        except AssertionError:
            debug_path = ROOT / "artifacts" / f"fail_{combo[0]}_{combo[1]}.html"
            debug_path.parent.mkdir(parents=True, exist_ok=True)
            with open(debug_path, "w", encoding="utf-8") as fh:
                fh.write(page.content())
            session_logger.error("Assertion failed; saved page content to %s", debug_path)
            raise
    else:
        session_logger.info("No browser started (docs-only mode).")
