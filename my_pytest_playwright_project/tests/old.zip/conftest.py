import pytest
import lxml.etree as ET
from pathlib import Path

import json
import os
from pathlib import Path
from lxml import etree as ET
import pytest

def pytest_generate_tests(metafunc):
    pointer_file = Path("data/output/latest.json")
    if not pointer_file.exists():
        raise FileNotFoundError(
            "Pointer file 'data/output/latest.json' not found. "
            "Run the Excel→XML converter first."
        )

    with open(pointer_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    current_folder = data.get("current_output")
    if not current_folder:
        raise ValueError("Invalid latest.json: missing 'current_output' field.")

    xml_path = Path("data/output") / current_folder / "test_cases.xml"
    if not xml_path.exists():
        raise FileNotFoundError(f"Missing expected XML: {xml_path}")

    # Example of using the XML for parametrization
    tree = ET.parse(str(xml_path))
    root = tree.getroot()
    tests = root.findall(".//test")  # or whatever node set you use

    metafunc.parametrize("testcase", tests)

@pytest.fixture
def page(playwright):
    browser = playwright.chromium.launch()
    context = browser.new_context()
    page = context.new_page()
    yield page
    browser.close()

def test_ui_case(test_name, steps, page):
    for step in steps:
        # Example: translate your verbs → Playwright actions
        action = step["action"].lower()
        target = step["element"]
        value = step["input"]

        if action == "click":
            page.click(target)
        elif action == "enter":
            page.fill(target, value)
        elif action == "check":
            assert step["expected"] in page.text_content(target)
